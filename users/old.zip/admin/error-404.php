<div class="position-relative min-vh-100 d-flex align-items-center justify-content-center pt-0">
  <div class="d-flex align-items-center justify-content-center w-100">
    <div class="row justify-content-center w-100">
      <div class="col-lg-4">
        <div class="text-center">
          <h1 class="fw-semibold mb-7 fs-9">Opps!!!</h1>
          <h4 class="fw-semibold mb-7">This page you are looking for could not be found.</h4>
          <a class="btn btn-primary" href="dashboard.php" role="button">Go Back to Home</a>
        </div>
      </div>
    </div>
  </div>
</div>