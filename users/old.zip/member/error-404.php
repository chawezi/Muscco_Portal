<div class="position-relative min-vh-100 d-flex align-items-center justify-content-center pt-0">
  <div class="d-flex align-items-center justify-content-center w-100">
    <div class="row justify-content-center w-100">
      <div class="card">
              <div class="card-body text-center">
                <img src="../../dist/images/backgrounds/website-under-construction.gif" alt="" class="img-fluid mb-4" width="200">
                <h5 class="fw-semibold fs-5 mb-2">Oops something went wrong!</h5>
                <p class="mb-3 px-xl-5">The page you are looking for could not be found.</p>
                <a class="btn btn-primary" href="dashboard.php" role="button">Go Back to Home</a>
              </div>
            </div>
      
      </div>
    </div>
  </div>
</div>